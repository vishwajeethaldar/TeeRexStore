import Routes from './routes/Routes'

function App() {
  return (
    <div>
      {/* Executing only Routes component here */}
      <Routes />
    </div>
  )
}

export default App
