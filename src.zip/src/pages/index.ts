// exporting all pages 
export {default as Cart} from './Cart'
export {default as Home} from './Home'